# DNS Resolution Exporter Helm Chart

This Helm chart deploys the DNS Resolution Exporter, which monitors domain availability through DNS resolution and exports metrics for Prometheus/Grafana.

## Prerequisites

- Kubernetes 1.16+
- Helm 3.0+
- Optional: Prometheus Operator for ServiceMonitor

## Installing the Chart

1. First, build and push the Docker image:

```bash
# From the directory containing your source files
docker build -t your-registry/dns-exporter:latest -f Dockerfile .
docker push your-registry/dns-exporter:latest
```

2. Install the chart:

```bash
helm install dns-exporter ./dns-exporter \
  --set image.repository=your-registry/dns-exporter \
  --set image.tag=latest
```

## Configuration

The following table lists the configurable parameters of the chart and their default values:

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of DNS exporter replicas | `1` |
| `image.repository` | DNS exporter image repository | `dns-exporter` |
| `image.tag` | DNS exporter image tag | `latest` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `service.type` | Kubernetes service type | `ClusterIP` |
| `service.port` | Kubernetes service port | `9369` |
| `config.listenPort` | Port on which the DNS exporter listens | `9369` |
| `config.checkInterval` | Interval between DNS checks in seconds | `60` |
| `config.domains` | List of domains to check | See `values.yaml` for defaults |
| `resources` | CPU/Memory resource requests/limits | See `values.yaml` for defaults |
| `prometheus.serviceMonitor.enabled` | Enable ServiceMonitor for Prometheus Operator | `false` |
| `prometheus.serviceMonitor.interval` | Interval at which metrics should be scraped | `15s` |
| `prometheus.serviceMonitor.scrapeTimeout` | Timeout after which the scrape is ended | `10s` |

## Adding domains to monitor

Edit the `values.yaml` file to add domains to the `config.domains` list:

```yaml
config:
  domains:
    - "# Список доменов для проверки"
    - "# Каждый домен на отдельной строке"
    - "example.com"
    - "test.example.org"
```

Alternatively, use `--set` when installing/upgrading:

```bash
helm install dns-exporter ./dns-exporter \
  --set config.domains[0]="example.com" \
  --set config.domains[1]="test.example.org"
```

## Integration with Prometheus and Grafana

### Prometheus Configuration

If not using ServiceMonitor, configure Prometheus to scrape from the DNS exporter:

```yaml
scrape_configs:
  - job_name: 'dns-exporter'
    kubernetes_sd_configs:
      - role: endpoints
        namespaces:
          names:
            - <namespace>
    relabel_configs:
      - source_labels: [__meta_kubernetes_service_name]
        regex: dns-exporter
        action: keep
```

### Grafana Dashboard

Import the provided Grafana dashboard from the `dns_dashboard.json` file in your source repository.
